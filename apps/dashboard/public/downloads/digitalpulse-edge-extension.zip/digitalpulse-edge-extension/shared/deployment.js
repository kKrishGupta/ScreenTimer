// Generated public configuration. No secrets.
export const DEPLOYMENT = "production";
export const BACKEND_URL = "https://screentimer.onrender.com";
