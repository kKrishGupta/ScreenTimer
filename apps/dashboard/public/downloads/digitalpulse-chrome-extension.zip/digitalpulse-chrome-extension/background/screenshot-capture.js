import { resolveBackendUrl } from '../shared/backend-settings.js';

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const CAPTURE_FORMAT = 'jpeg';
const CAPTURE_QUALITY = 75;

function futureTime(value) {
  const timestamp = Date.parse(value || '');
  return Number.isFinite(timestamp) && timestamp > Date.now();
}

function decodeDataUrl(dataUrl) {
  const match = /^data:(image\/(?:jpeg|png));base64,([a-z0-9+/=]+)$/i.exec(dataUrl || '');
  if (!match) throw new Error('Capture API returned an unsupported image payload.');
  const binary = atob(match[2]);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  if (bytes.length < 32 || bytes.length > MAX_IMAGE_BYTES) throw new Error('Capture image size is invalid.');
  return { bytes, mimeType: match[1].toLowerCase() };
}

function imageDimensions(bytes, mimeType) {
  if (mimeType === 'image/png') {
    if (bytes.length < 24 || !bytes.subarray(0, 8).every((value, index) => value === [137, 80, 78, 71, 13, 10, 26, 10][index])) throw new Error('Capture image signature is invalid.');
    return { width: new DataView(bytes.buffer, bytes.byteOffset).getUint32(16), height: new DataView(bytes.buffer, bytes.byteOffset).getUint32(20) };
  }
  if (bytes[0] !== 0xff || bytes[1] !== 0xd8 || bytes.at(-2) !== 0xff || bytes.at(-1) !== 0xd9) throw new Error('Capture image signature is invalid.');
  for (let offset = 2; offset + 9 < bytes.length;) {
    if (bytes[offset++] !== 0xff) throw new Error('Capture JPEG structure is invalid.');
    while (bytes[offset] === 0xff) offset += 1;
    const marker = bytes[offset++];
    if (marker === 0xd8 || marker === 0xd9) continue;
    if (offset + 2 > bytes.length) break;
    const length = (bytes[offset] << 8) | bytes[offset + 1];
    if (length < 2 || offset + length > bytes.length) break;
    if ([0xc0, 0xc1, 0xc2, 0xc3].includes(marker) && length >= 7) {
      return { width: (bytes[offset + 5] << 8) | bytes[offset + 6], height: (bytes[offset + 3] << 8) | bytes[offset + 4] };
    }
    offset += length;
  }
  throw new Error('Capture JPEG dimensions are unavailable.');
}

function captureKey() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID().replaceAll('-', '');
  return `${Date.now()}_${Math.random().toString(36).slice(2)}`;
}

export async function setMonitoringIndicator(chromeApi, active, reason = '') {
  if (!chromeApi?.action?.setBadgeText || !chromeApi?.action?.setBadgeBackgroundColor) return false;
  try {
    await chromeApi.action.setBadgeText({ text: active ? 'ON' : '' });
    if (active) {
      await chromeApi.action.setBadgeBackgroundColor({ color: '#16a34a' });
      await chromeApi.action.setTitle?.({ title: 'DigitalPulse: browser screenshot monitoring is active' });
    } else {
      await chromeApi.action.setBadgeBackgroundColor({ color: '#64748b' });
      await chromeApi.action.setTitle?.({ title: `DigitalPulse: monitoring paused${reason ? ` (${reason})` : ''}` });
    }
    await chromeApi.storage.local.set({ dp_monitoring_indicator_active: active === true });
    return true;
  } catch {
    await chromeApi.storage.local.set({ dp_monitoring_indicator_active: false });
    return false;
  }
}

async function readDeviceState(chromeApi, config) {
  const stored = await chromeApi.storage.local.get([
    config.DEVICE_STORAGE_KEY,
    config.SETTINGS_STORAGE_KEY,
    'dp_device_secret',
    'dp_last_screen_capture_at',
  ]);
  if (!stored[config.DEVICE_STORAGE_KEY] || !stored.dp_device_secret) throw new Error('DEVICE_NOT_ENROLLED');
  return stored;
}

async function fetchPolicy({ chromeApi, fetchImpl, config, stored }) {
  const backendUrl = resolveBackendUrl(stored, config);
  const deviceId = stored[config.DEVICE_STORAGE_KEY];
  const response = await fetchImpl(`${backendUrl}/api/v1/screen-monitoring/device-policy?deviceId=${encodeURIComponent(deviceId)}`, {
    method: 'GET',
    cache: 'no-store',
    redirect: 'error',
    signal: AbortSignal.timeout(10000),
    headers: { 'X-Device-Secret': stored.dp_device_secret },
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.policy) throw new Error(result.error?.code || `SCREEN_POLICY_UNAVAILABLE_${response.status}`);
  const policy = result.policy;
  if (policy.allowed !== true || policy.visibleIndicator !== true || !futureTime(policy.allowedUntil)) {
    throw new Error(policy.reason || 'MONITORING_NOT_AUTHORIZED');
  }
  return { ...policy, backendUrl, deviceId };
}

async function activeVisibleTab(chromeApi) {
  const focusedWindow = await chromeApi.windows.getLastFocused();
  if (!focusedWindow?.focused || focusedWindow.type === 'popup' || focusedWindow.type === 'devtools') throw new Error('BROWSER_WINDOW_NOT_VISIBLE');
  if (chromeApi.idle?.queryState && await chromeApi.idle.queryState(60) !== 'active') throw new Error('BROWSER_WINDOW_NOT_ACTIVE');
  const tabs = await chromeApi.tabs.query({ active: true, lastFocusedWindow: true });
  const tab = tabs?.[0];
  if (!tab?.id || tab.incognito || tab.active !== true || tab.windowId !== focusedWindow.id || tab.discarded) throw new Error('ACTIVE_TAB_NOT_ELIGIBLE');
  if (!/^https?:\/\//i.test(tab.url || '')) throw new Error('ACTIVE_TAB_NOT_ELIGIBLE');
  return tab;
}

function intervalElapsed(lastCaptureAt, intervalSeconds) {
  const timestamp = Date.parse(lastCaptureAt || '');
  return !Number.isFinite(timestamp) || Date.now() - timestamp >= Number(intervalSeconds || 300) * 1000;
}

export function createScreenshotCapture({ chromeApi, fetchImpl, config, browserName }) {
  let inFlight = null;

  async function reportFailure(stored, code) {
    try {
      const backendUrl = resolveBackendUrl(stored, config);
      await fetchImpl(`${backendUrl}/api/v1/screen-monitoring/failures`, {
        method: 'POST',
        redirect: 'error',
        signal: AbortSignal.timeout(10000),
        headers: { 'Content-Type': 'application/json', 'X-Device-Secret': stored.dp_device_secret },
        body: JSON.stringify({ deviceId: stored[config.DEVICE_STORAGE_KEY], failureCode: code }),
      });
    } catch { /* Failure reporting must never create a capture retry loop. */ }
  }

  async function captureAuthorizedActiveTab() {
    if (inFlight) return inFlight;
    inFlight = performCapture().finally(() => { inFlight = null; });
    return inFlight;
  }

  async function performCapture() {
    let stored;
    try {
      stored = await readDeviceState(chromeApi, config);
      const policy = await fetchPolicy({ chromeApi, fetchImpl, config, stored });
      if (!intervalElapsed(stored.dp_last_screen_capture_at, policy.intervalSeconds)) return { skipped: true, reason: 'CAPTURE_INTERVAL_NOT_ELAPSED' };
      if (!await setMonitoringIndicator(chromeApi, true)) throw new Error('VISIBLE_INDICATOR_UNAVAILABLE');
      const tab = await activeVisibleTab(chromeApi);
      const capturedAt = new Date().toISOString();
      const dataUrl = await chromeApi.tabs.captureVisibleTab(tab.windowId, { format: CAPTURE_FORMAT, quality: CAPTURE_QUALITY });
      const image = decodeDataUrl(dataUrl);
      const dimensions = imageDimensions(image.bytes, image.mimeType);

      const latestStored = await chromeApi.storage.local.get(['dp_monitoring_indicator_active']);
      const latestPolicy = await fetchPolicy({ chromeApi, fetchImpl, config, stored: await readDeviceState(chromeApi, config) });
      const latestTab = await activeVisibleTab(chromeApi);
      if (latestStored.dp_monitoring_indicator_active !== true || latestTab.id !== tab.id || !latestPolicy.allowed) throw new Error('MONITORING_WITHDRAWN_BEFORE_UPLOAD');

      const response = await fetchImpl(`${latestPolicy.backendUrl}/api/v1/screen-monitoring/captures?deviceId=${encodeURIComponent(latestPolicy.deviceId)}`, {
        method: 'POST',
        redirect: 'error',
        signal: AbortSignal.timeout(15000),
        headers: {
          'Content-Type': image.mimeType,
          'X-Device-Secret': stored.dp_device_secret,
          'X-Capture-Key': captureKey(),
          'X-Captured-At': capturedAt,
          'X-Image-Width': String(dimensions.width),
          'X-Image-Height': String(dimensions.height),
          'X-Application-Name': `${browserName === 'edge' ? 'Edge' : 'Chrome'} - Active Tab`,
        },
        body: image.bytes,
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok || result.success !== true) throw new Error(result.error?.code ? `SCREEN_UPLOAD_${result.error.code}` : `SCREEN_UPLOAD_FAILED_${response.status}`);
      await chromeApi.storage.local.set({ dp_last_screen_capture_at: capturedAt, dp_last_screen_capture_id: result.captureId || null, dp_screen_capture_error: '' });
      return { success: true, captureId: result.captureId, capturedAt, dimensions };
    } catch (error) {
      if (stored) {
        await chromeApi.storage.local.set({ dp_screen_capture_error: error.message || 'SCREEN_CAPTURE_FAILED' });
        if (!['CAPTURE_INTERVAL_NOT_ELAPSED', 'MONITORING_NOT_AUTHORIZED', 'SCREEN_POLICY_UNAVAILABLE_403', 'MONITORING_WITHDRAWN_BEFORE_UPLOAD'].includes(error.message)) await reportFailure(stored, error.message?.startsWith('SCREEN_UPLOAD') ? 'UPLOAD_FAILED' : 'CAPTURE_API_FAILED');
      }
      const policyDenied = !String(error.message || '').startsWith('SCREEN_UPLOAD_') && /^(DEVICE_|SCREEN_|USER_|ADMIN_|OUTSIDE_|ACCOUNT_|ORGANIZATION_|SCHEDULE_|MONITORING_)/.test(error.message || '');
      if (policyDenied || error.message === 'VISIBLE_INDICATOR_UNAVAILABLE') await setMonitoringIndicator(chromeApi, false, error.message);
      if (error.message === 'CAPTURE_INTERVAL_NOT_ELAPSED') return { skipped: true, reason: error.message };
      return { success: false, error: error.message || 'SCREEN_CAPTURE_FAILED' };
    }
  }

  return { captureAuthorizedActiveTab };
}

export { decodeDataUrl, imageDimensions, intervalElapsed };
