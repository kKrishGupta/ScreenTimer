// Generated public configuration. No secrets.
export const BACKEND_URL = "http://127.0.0.1:3001";
